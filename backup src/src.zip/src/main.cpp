#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_ADS1X15.h>

// --- OBJECTS ---
Adafruit_ADS1115 ads;

// --- DATA STRUCTURE ---
struct AnalogConfig
{
  String name;
  String inputType;
  float slope;      // m
  float intercept;  // c
  int16_t adcValue; 
  float customRaw;  // Result (y)
  float tempValue;  // Final Temperature in °C
};

// Global Array
AnalogConfig analogInput[4];

// --- HARDWARE CONFIGURATION ---
float shuntResistor = 470.0; 

// --- CALIBRATION FOR TEMPERATURE DISPLAY ---
// Restored these to calculate the °C value
float x1_raw = 5333.0;   
float x2_raw = 26666.0;  
float y1_temp = -19.9;   
float y2_temp = 60.0;    

// --- FORWARD DECLARATION ---
void readAnalogSensors();

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);

  Serial.println("--- SYSTEM STARTING (Linear + Temp Display) ---");

  Wire.begin();
  if (!ads.begin()) {
    Serial.println("Error: ADS1115 not found. Check wiring!");
    while (1);
  }
  
  ads.setGain(GAIN_TWOTHIRDS);

  // ==========================================
  // CONFIGURE CHANNEL 0
  // ==========================================
  analogInput[0].name = "Temp Sensor";
  analogInput[0].inputType = "4-20 mA";

  // FORMULA CONFIGURATION: y = mx + c
  analogInput[0].slope = 6826.71;  
  analogInput[0].intercept = 0.0;
}

void loop() {
  readAnalogSensors();
  delay(1000); 
}

// ============================================================================
// SENSOR READING FUNCTION
// ============================================================================
void readAnalogSensors()
{
  for (int i = 0; i < 1; i++) 
  {
    // 1. Read Physical Data
    int16_t adc0_signed = ads.readADC_SingleEnded(i);
    float voltage_detected = ads.computeVolts(adc0_signed); 
    
    // 2. Calculate 'x' (Input in mA)
    float cleanMA = (voltage_detected / shuntResistor) * 1000.0;

    // 3. APPLY FORMULA: y = mx + c (Custom Raw)
    float m = analogInput[i].slope;
    float c = analogInput[i].intercept;
    float x = cleanMA; 

    if (analogInput[i].inputType.indexOf("V") >= 0) {
       x = voltage_detected; 
    }

    // Calculation (No Clamping)
    float y = (m * x) + c; 
    analogInput[i].customRaw = y;

    // 4. CALCULATE TEMPERATURE (°C)
    // Using the standard mapping variables you provided
    float rawValueForMap = (float)((uint16_t)adc0_signed);
    float temp = (rawValueForMap - x1_raw) * (y2_temp - y1_temp) / (x2_raw - x1_raw) + y1_temp;
    analogInput[i].tempValue = temp;

    // 5. Output
    Serial.print("[CH-"); Serial.print(i); Serial.print("] ");
    Serial.print(" | CustomRaw: "); Serial.print(analogInput[i].customRaw, 0); 
    Serial.print(" | Temp: "); Serial.print(analogInput[i].tempValue, 2); Serial.println(" °C");
  }
}